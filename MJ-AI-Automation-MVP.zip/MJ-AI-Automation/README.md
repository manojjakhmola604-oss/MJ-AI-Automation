# MJ AI Automation — MVP

Android starter project for an AI-first automation and security assistant.

## Current MVP
- Natural-language/Hinglish command parser
- Automation rule preview with confidence
- Notification Listener foundation
- URL/link risk scanning foundation
- Explicit Android settings flow for notification access
- Safety boundary for high-impact actions

## Build
Open the folder in Android Studio, allow Gradle sync, then run on an Android 8+ device/emulator.

## Next phases
1. Replace local parser with an optional AI backend/API.
2. Add persistent rule database and scheduler.
3. Add battery/time/location/context triggers.
4. Add call/SMS spam detection using Android-supported roles/APIs.
5. Add a visible security warning notification for risky links.
6. Add undo/history and per-action confirmation.
7. Add privacy dashboard and on-device-first processing.

Note: Android and third-party apps restrict some actions. Do not bypass those restrictions; use supported APIs/permissions and user-approved roles.

package com.mj.aiautomation

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class SecurityNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val extras = sbn.notification.extras
        val text = listOf(extras.getCharSequence("android.title"), extras.getCharSequence("android.text")).filterNotNull().joinToString(" ")
        if (text.contains("http://", true) || text.contains("https://", true) || text.contains("www.", true)) {
            val risk = LinkRiskScanner.assess(text)
            // MVP hook: replace with an in-app warning/notification in the next phase.
            android.util.Log.w("MJ_SECURITY", risk)
        }
    }
}

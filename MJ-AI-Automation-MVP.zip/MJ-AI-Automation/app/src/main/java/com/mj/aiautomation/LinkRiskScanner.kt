package com.mj.aiautomation

import android.util.Patterns

object LinkRiskScanner {
    fun assess(text: String): String {
        val url = Patterns.WEB_URL.matcher(text).takeIf { it.find() }?.group() ?: return "No URL detected."
        val suspicious = listOf("bit.ly", "tinyurl", "login-", "verify-", "secure-", ".xyz", ".top", ".click").any { url.contains(it, true) }
        return if (suspicious) "HIGH RISK: suspicious URL pattern detected: $url" else "CAUTION: URL found. Verify the domain before entering passwords, OTPs or UPI PINs: $url"
    }
}

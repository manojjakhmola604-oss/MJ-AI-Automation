package com.mj.aiautomation

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val command = findViewById<EditText>(R.id.command)
        val result = findViewById<TextView>(R.id.result)
        findViewById<Button>(R.id.create).setOnClickListener {
            val rule = CommandParser.parse(command.text.toString())
            result.text = rule?.let { "Trigger: ${it.trigger}\nAction: ${it.action}\nAI confidence: ${it.confidence}%\n\nThis MVP previews the rule; high-impact actions require user confirmation." } ?: "I couldn't safely convert that command yet. Try: ‘battery 20% par saver on karo’ or ‘11 baje DND on karo’."
        }
        findViewById<Button>(R.id.security).setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
    }
}

package com.mj.aiautomation

data class AutomationRule(val trigger: String, val action: String, val confidence: Int)

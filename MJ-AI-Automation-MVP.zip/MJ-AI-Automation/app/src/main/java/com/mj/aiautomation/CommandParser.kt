package com.mj.aiautomation

object CommandParser {
    fun parse(input: String): AutomationRule? {
        val s = input.lowercase()
        return when {
            s.contains("battery") && (s.contains("20") || s.contains("20%")) -> AutomationRule("Battery <= 20%", "Suggest Battery Saver", 92)
            s.contains("11") && (s.contains("silent") || s.contains("dnd") || s.contains("do not disturb")) -> AutomationRule("Time = 11:00 PM", "Enable Do Not Disturb (confirmation required)", 88)
            s.contains("office") && (s.contains("silent") || s.contains("dnd")) -> AutomationRule("Office context detected", "Enable Work/DND mode (confirmation required)", 84)
            s.contains("link") && (s.contains("check") || s.contains("scan")) -> AutomationRule("New notification containing URL", "Run phishing-risk scan", 90)
            else -> null
        }
    }
}

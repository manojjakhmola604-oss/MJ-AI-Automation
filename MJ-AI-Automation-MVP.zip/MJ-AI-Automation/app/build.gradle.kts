plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace = "com.mj.aiautomation"; compileSdk = 35
    defaultConfig { applicationId = "com.mj.aiautomation"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "0.1.0" }
}

kotlin { jvmToolchain(17) }
